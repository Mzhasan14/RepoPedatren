<?php

namespace App\Services\Administrasi;

use App\Models\Catatan_afektif;
use App\Models\Santri;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CatatanAfektifService
{
    public function baseCatatanAfektifQuery(Request $request)
    {
        $user = $request->user();

        $pasFotoId = DB::table('jenis_berkas')
            ->where('nama_jenis_berkas', 'Pas foto')
            ->value('id');

        $fotoLast = DB::table('berkas')
            ->select('biodata_id', DB::raw('MAX(id) AS last_id'))
            ->where('jenis_berkas_id', $pasFotoId)
            ->groupBy('biodata_id');

        // Ambil ID wali_asuh jika user role wali_asuh
        $waliAsuhId = null;
        if ($user->hasRole('wali_asuh')) {
            $waliAsuhId = DB::table('wali_asuh as wa')
                ->join('santri as s', 's.id', '=', 'wa.id_santri')
                ->where('s.biodata_id', $user->biodata_id)
                ->value('wa.id');
        }

        $query = DB::table('catatan_afektif')
            ->join('santri as cs', 'cs.id', '=', 'catatan_afektif.id_santri')
            ->join('biodata as bs', 'bs.id', '=', 'cs.biodata_id')
            ->leftJoin('domisili_santri', 'domisili_santri.santri_id', '=', 'cs.id')
            ->leftJoin('wilayah', 'wilayah.id', '=', 'domisili_santri.wilayah_id')
            ->leftJoin('blok', 'blok.id', '=', 'domisili_santri.blok_id')
            ->leftJoin('kamar', 'kamar.id', '=', 'domisili_santri.kamar_id')
            ->leftJoin('pendidikan', 'pendidikan.biodata_id', '=', 'bs.id')
            ->leftJoin('lembaga', 'lembaga.id', '=', 'pendidikan.lembaga_id')
            ->leftJoin('jurusan', 'jurusan.id', '=', 'pendidikan.jurusan_id')
            ->leftJoin('kelas', 'kelas.id', '=', 'pendidikan.kelas_id')
            ->leftJoin('rombel', 'rombel.id', '=', 'pendidikan.rombel_id')

            // Relasi wali_asuh → pencatat biasa
            ->leftJoin('wali_asuh', 'wali_asuh.id', '=', 'catatan_afektif.id_wali_asuh')
            ->leftJoin('santri as ps', 'ps.id', '=', 'wali_asuh.id_santri')
            ->leftJoin('biodata as bp', 'bp.id', '=', 'ps.biodata_id')

            // Relasi created_by → user → role superadmin
            ->leftJoin('users as cu', 'cu.id', '=', 'catatan_afektif.created_by')
            ->leftJoin('biodata as bsc', 'bsc.id', '=', 'cu.biodata_id')
            ->leftJoin('model_has_roles as mhr', function ($join) {
                $join->on('cu.id', '=', 'mhr.model_id')
                    ->where('mhr.model_type', '=', DB::raw("'App\\\\Models\\\\User'"));
            })
            ->leftJoin('roles as r', 'r.id', '=', 'mhr.role_id')

            // Foto santri (catatan)
            ->leftJoinSub($fotoLast, 'fotoLastCatatan', function ($join) {
                $join->on('bs.id', '=', 'fotoLastCatatan.biodata_id');
            })
            ->leftJoin('berkas as FotoCatatan', 'FotoCatatan.id', '=', 'fotoLastCatatan.last_id')

            // Foto pencatat (wali_asuh)
            ->leftJoinSub($fotoLast, 'fotoLastPencatat', function ($join) {
                $join->on('bp.id', '=', 'fotoLastPencatat.biodata_id');
            })
            ->leftJoin('berkas as FotoPencatat', 'FotoPencatat.id', '=', 'fotoLastPencatat.last_id')

            // Foto superadmin
            ->leftJoinSub($fotoLast, 'fotoLastSuperAdmin', function ($join) {
                $join->on('bsc.id', '=', 'fotoLastSuperAdmin.biodata_id');
            })
            ->leftJoin('berkas as FotoSuperAdmin', 'FotoSuperAdmin.id', '=', 'fotoLastSuperAdmin.last_id')

            ->orderBy('catatan_afektif.tanggal_buat', 'desc');

        // Filter khusus wali_asuh
        if ($user->hasRole('wali_asuh') && $waliAsuhId) {
            $query->where('catatan_afektif.id_wali_asuh', $waliAsuhId);
        } elseif ($user->hasRole('wali_asuh') && !$waliAsuhId) {
            $query->whereRaw('1=0'); // user wali_asuh tapi tidak punya relasi → kosong
        }

        return $query;
    }

    public function getAllCatatanAfektif(Request $request)
    {
        try {
            $query = $this->baseCatatanAfektifQuery($request);

            return $query->select(
                'catatan_afektif.id as id_catatan',
                'bs.id as Biodata_uuid',

                // Pencatat UUID: superadmin → biodata UUID, wali_asuh → bp.id
                DB::raw("
                CASE
                    WHEN r.name = 'superadmin' THEN bsc.id
                    WHEN catatan_afektif.id_wali_asuh IS NOT NULL THEN bp.id
                    ELSE NULL
                END as Pencatat_uuid
            "),

                'bs.nama',
                DB::raw("GROUP_CONCAT(DISTINCT blok.nama_blok SEPARATOR ', ') as blok"),
                DB::raw("GROUP_CONCAT(DISTINCT wilayah.nama_wilayah SEPARATOR ', ') as wilayah"),
                DB::raw("GROUP_CONCAT(DISTINCT jurusan.nama_jurusan SEPARATOR ', ') as jurusan"),
                DB::raw("GROUP_CONCAT(DISTINCT lembaga.nama_lembaga SEPARATOR ', ') as lembaga"),
                'catatan_afektif.kepedulian_nilai',
                'catatan_afektif.kepedulian_tindak_lanjut',
                'catatan_afektif.kebersihan_nilai',
                'catatan_afektif.kebersihan_tindak_lanjut',
                'catatan_afektif.akhlak_nilai',
                'catatan_afektif.akhlak_tindak_lanjut',

                // Nama pencatat
                DB::raw("
                CASE
                    WHEN r.name = 'superadmin' THEN COALESCE(bsc.nama, cu.name, 'Super Admin')
                    WHEN catatan_afektif.id_wali_asuh IS NOT NULL THEN bp.nama
                    ELSE 'Tidak diketahui'
                END as pencatat
            "),

                // Jabatan pencatat
                DB::raw("
                CASE
                    WHEN r.name = 'superadmin' THEN 'superadmin'
                    WHEN catatan_afektif.id_wali_asuh IS NOT NULL THEN 'wali asuh'
                    ELSE NULL
                END as wali_asuh
            "),

                'catatan_afektif.tanggal_buat',
                DB::raw("COALESCE(FotoCatatan.file_path, 'default.jpg') as foto_catatan"),

                // Foto pencatat
                DB::raw("
                CASE
                    WHEN r.name = 'superadmin' THEN COALESCE(FotoSuperAdmin.file_path, 'default.jpg')
                    WHEN catatan_afektif.id_wali_asuh IS NOT NULL THEN COALESCE(FotoPencatat.file_path, 'default.jpg')
                    ELSE 'default.jpg'
                END as foto_pencatat
            ")
            )
                ->groupBy(
                    'catatan_afektif.id',
                    'catatan_afektif.id_wali_asuh',
                    'bs.id',
                    'bs.nama',
                    'bp.id',
                    'bp.nama',
                    'cu.id',
                    'cu.name',
                    'bsc.id',
                    'bsc.nama',
                    'wali_asuh.id',
                    'r.name',
                    'catatan_afektif.kepedulian_nilai',
                    'catatan_afektif.kepedulian_tindak_lanjut',
                    'catatan_afektif.kebersihan_nilai',
                    'catatan_afektif.kebersihan_tindak_lanjut',
                    'catatan_afektif.akhlak_nilai',
                    'catatan_afektif.akhlak_tindak_lanjut',
                    'catatan_afektif.tanggal_buat',
                    'FotoCatatan.file_path',
                    'FotoPencatat.file_path',
                    'FotoSuperAdmin.file_path'
                );
        } catch (\Exception $e) {
            Log::error('Error fetching data Catatan Afektif: ' . $e->getMessage());

            return response()->json([
                'status' => 'error',
                'message' => 'Terjadi kesalahan saat mengambil data Catatan Afektif',
                'code' => 500,
            ], 500);
        }
    }

    public function formatData($results, $kategori = null)
    {
        $kategori = strtolower($kategori);

        return collect($results->items())->flatMap(function ($item) use ($kategori) {
            $data = [];

            if ($kategori === 'akhlak') {
                if ($item->akhlak_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Akhlak',
                        'nilai' => $item->akhlak_nilai,
                        'tindak_lanjut' => $item->akhlak_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
            } elseif ($kategori === 'kepedulian') {
                if ($item->kepedulian_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Kepedulian',
                        'nilai' => $item->kepedulian_nilai,
                        'tindak_lanjut' => $item->kepedulian_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
            } elseif ($kategori === 'kebersihan') {
                if ($item->kebersihan_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Kebersihan',
                        'nilai' => $item->kebersihan_nilai,
                        'tindak_lanjut' => $item->kebersihan_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
            } else {
                // Kalau kategori null / tidak dipilih, munculkan semua kategori yang ada nilai
                if ($item->akhlak_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Akhlak',
                        'nilai' => $item->akhlak_nilai,
                        'tindak_lanjut' => $item->akhlak_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
                if ($item->kepedulian_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Kepedulian',
                        'nilai' => $item->kepedulian_nilai,
                        'tindak_lanjut' => $item->kepedulian_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
                if ($item->kebersihan_nilai !== null) {
                    $data[] = [
                        'Biodata_uuid' => $item->Biodata_uuid,
                        'Pencatat_uuid' => $item->Pencatat_uuid,
                        'id_catatan' => $item->id_catatan,
                        'nama_santri' => $item->nama,
                        'blok' => $item->blok,
                        'wilayah' => $item->wilayah,
                        'pendidikan' => $item->jurusan,
                        'lembaga' => $item->lembaga,
                        'kategori' => 'Kebersihan',
                        'nilai' => $item->kebersihan_nilai,
                        'tindak_lanjut' => $item->kebersihan_tindak_lanjut,
                        'pencatat' => $item->pencatat,
                        'jabatanPencatat' => $item->wali_asuh,
                        'waktu_pencatatan' => Carbon::parse($item->tanggal_buat)->format('d M Y H:i:s'),
                        'foto_catatan' => url($item->foto_catatan),
                        'foto_pencatat' => url($item->foto_pencatat),
                    ];
                }
            }

            return $data;
        });
    }

    public function store(array $input, Request $request)
    {
        $user = $request->user();

        // Pastikan hanya wali_asuh atau superadmin yang dapat membuat catatan
        if (! $user->hasRole('wali_asuh') && ! $user->hasRole('superadmin')) {
            return [
                'status' => false,
                'message' => 'Hanya wali asuh atau superadmin yang dapat membuat catatan afektif.',
                'data' => null,
            ];
        }

        // Ambil data anak_asuh beserta wali_asuh_id dari grupnya
        $anakAsuh = DB::table('anak_asuh as aa')
            ->join('grup_wali_asuh as g', 'aa.grup_wali_asuh_id', '=', 'g.id')
            ->select('aa.*', 'g.wali_asuh_id')
            ->where('aa.id', $input['id_anak_asuh'])
            ->first();

        if (! $anakAsuh) {
            return [
                'status' => false,
                'message' => 'Data anak asuh tidak ditemukan.',
                'data' => null,
            ];
        }

        $idSantri = $anakAsuh->id_santri;
        $waliAsuhId = null;

        // Tentukan id_wali_asuh
        if ($user->hasRole('wali_asuh')) {
            // Ambil ID wali_asuh dari user login
            $waliAsuhId = DB::table('wali_asuh as wa')
                ->join('santri as s', 's.id', '=', 'wa.id_santri')
                ->join('biodata as b', 'b.id', '=', 's.biodata_id')
                ->join('users as u', 'u.biodata_id', '=', 'b.id')
                ->where('u.id', $user->id)
                ->value('wa.id');

            if (! $waliAsuhId) {
                return [
                    'status' => false,
                    'message' => 'Anda tidak memiliki anak asuh.',
                    'data' => null,
                ];
            }

            // Cek apakah anak_asuh termasuk grup wali_asuh ini
            if ($anakAsuh->wali_asuh_id != $waliAsuhId) {
                return [
                    'status' => false,
                    'message' => 'Santri bukan anak asuh Anda.',
                    'data' => null,
                ];
            }
        } else {
            // Superadmin → cek dulu grup apakah punya wali_asuh_id
            $waliAsuhId = $anakAsuh->wali_asuh_id ?: null;
        }

        // Cek status santri
        $santriObj = Santri::find($idSantri);
        if (! $santriObj || $santriObj->status !== 'aktif') {
            return [
                'status' => false,
                'message' => 'Santri tidak aktif. Tidak bisa menambahkan catatan afektif.',
                'data' => null,
            ];
        }

        // Simpan catatan baru
        $catatan = Catatan_afektif::create([
            'id_santri' => $idSantri,
            'id_wali_asuh' => $waliAsuhId, // nullable
            'kepedulian_nilai' => $input['kepedulian_nilai'],
            'kepedulian_tindak_lanjut' => $input['kepedulian_tindak_lanjut'],
            'kebersihan_nilai' => $input['kebersihan_nilai'],
            'kebersihan_tindak_lanjut' => $input['kebersihan_tindak_lanjut'],
            'akhlak_nilai' => $input['akhlak_nilai'],
            'akhlak_tindak_lanjut' => $input['akhlak_tindak_lanjut'],
            'tanggal_buat' => $input['tanggal_buat'] ?? now(),
            'status' => true,
            'created_by' => $user->id,
            'created_at' => now(),
        ]);

        return [
            'status' => true,
            'message' => 'Catatan afektif berhasil ditambahkan.',
            'data' => $catatan,
        ];
    }
    public function updateKategori($id, Request $request)
    {
        $kategori = $request->kategori;
        $nilai = $request->nilai;
        $tindakLanjut = $request->tindak_lanjut;

        $kolomNilai = "{$kategori}_nilai";
        $kolomTindakLanjut = "{$kategori}_tindak_lanjut";

        $allowedColumns = [
            'akhlak_nilai',
            'akhlak_tindak_lanjut',
            'kepedulian_nilai',
            'kepedulian_tindak_lanjut',
            'kebersihan_nilai',
            'kebersihan_tindak_lanjut',
        ];

        if (!in_array($kolomNilai, $allowedColumns) || !in_array($kolomTindakLanjut, $allowedColumns)) {
            throw new \Exception("Kolom tidak valid.");
        }

        $catatan = Catatan_afektif::findOrFail($id);

        // Cek kondisi sebelum update
        if (!is_null($catatan->tanggal_selesai)) {
            throw new \Exception("Data tidak bisa diubah karena sudah tidak aktif lagi.");
        }

        if ($catatan->status !== 1) {
            throw new \Exception("Data tidak bisa diubah karena status tidak aktif.");
        }

        // Update jika lolos pengecekan
        $catatan->$kolomNilai = $nilai;
        $catatan->$kolomTindakLanjut = $tindakLanjut;
        $catatan->updated_by = Auth::id();
        $catatan->save();

        return $catatan->refresh(); // Mengembalikan data terbaru
    }
}
