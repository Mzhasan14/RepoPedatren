<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class WaliAnakAsuhSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        DB::table('kewaliasuhan')->delete();
        DB::table('anak_asuh')->delete();
        DB::table('wali_asuh')->delete();
        DB::table('grup_wali_asuh')->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        $santriList = DB::table('santri')->pluck('id')->toArray();
        shuffle($santriList);

        $wilayahList = DB::table('wilayah')->pluck('id')->toArray();
        $totalSantri = count($santriList);
        $jumlahGrup = max(20, min(25, intdiv($totalSantri, 13)));

        $waliAsuhList = array_slice($santriList, 0, $jumlahGrup);
        $anakAsuhList = array_slice($santriList, $jumlahGrup);

        // Ambil data biodata jenis kelamin
        $biodataMap = DB::table('biodata')
            ->join('santri', 'biodata.id', '=', 'santri.biodata_id')
            ->pluck('biodata.jenis_kelamin', 'santri.id');

        // Buat grup wali asuh
        $grupWaliAsuhData = [];
        $waliAsuhData = [];
        foreach ($waliAsuhList as $index => $santriId) {
            $jk = $biodataMap[$santriId] ?? 'l';
            $grupId = DB::table('grup_wali_asuh')->insertGetId([
                'id_wilayah' => $wilayahList[array_rand($wilayahList)],
                'nama_grup' => 'Grup Wali ' . ($index + 1),
                'jenis_kelamin' => $jk,
                'created_by' => 1,
                'status' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $waliAsuhId = DB::table('wali_asuh')->insertGetId([
                'id_santri' => $santriId,
                'id_grup_wali_asuh' => $grupId,
                'tanggal_mulai' => now()->subYears(rand(1, 5)),
                'tanggal_berakhir' => null,
                'created_by' => 1,
                'status' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            // Simpan untuk pencocokan anak asuh nanti
            $waliPool[] = [
                'id' => $waliAsuhId,
                'grup_id' => $grupId,
                'jenis_kelamin' => $jk,
            ];
        }

        // Anak Asuh
        foreach ($anakAsuhList as $santriId) {
            $anakAsuhId = DB::table('anak_asuh')->insertGetId([
                'id_santri' => $santriId,
                'created_by' => 1,
                'status' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            $jkAnak = $biodataMap[$santriId] ?? 'l';
            $waliCocok = collect($waliPool)->where('jenis_kelamin', $jkAnak)->shuffle()->first();

            if (! $waliCocok) continue;

            DB::table('kewaliasuhan')->insert([
                'id_wali_asuh' => $waliCocok['id'],
                'id_anak_asuh' => $anakAsuhId,
                'tanggal_mulai' => now()->subYears(rand(1, 5)),
                'tanggal_berakhir' => null,
                'created_by' => 1,
                'status' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}