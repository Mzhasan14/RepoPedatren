<?php

namespace App\Http\Controllers\api\kewaliasuhan;

use App\Models\Santri;
use App\Models\Biodata;
use App\Exports\BaseExport;
use Illuminate\Http\Request;
use App\Models\Peserta_didik;
use Illuminate\Http\JsonResponse;
use App\Http\Resources\PdResource;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Kewaliasuhan\Anak_asuh;
use App\Models\Kewaliasuhan\Kewaliasuhan;
use Illuminate\Support\Facades\Validator;
use App\Services\Kewaliasuhan\AnakasuhService;
use App\Http\Requests\Kewaliasuhan\anakAsuhRequest;
use App\Http\Requests\Kewaliasuhan\BerhentiAnakAsuhRequest;
use App\Services\Kewaliasuhan\DetailAnakasuhService;
use App\Http\Requests\Kewaliasuhan\KeluarAnakasuhRequest;
use App\Http\Requests\Kewaliasuhan\PindahAnakasuhRequest;
use App\Http\Requests\Kewaliasuhan\tambahAnakasuhRequest;
use App\Services\Kewaliasuhan\Filters\FilterAnakasuhService;

class AnakasuhController extends Controller
{
    private AnakasuhService $anakasuhService;

    private FilterAnakasuhService $filterAnakasuhService;

    private DetailAnakasuhService $detailAnakasuhService;

    public function __construct(AnakasuhService $anakasuhService, FilterAnakasuhService $filterAnakasuhService, DetailAnakasuhService $detailAnakasuhService)
    {
        $this->anakasuhService = $anakasuhService;
        $this->filterAnakasuhService = $filterAnakasuhService;
        $this->detailAnakasuhService = $detailAnakasuhService;
    }

    public function getAllAnakasuh(Request $request)
    {
        $query = $this->anakasuhService->getAllAnakasuh($request);
        $query = $this->filterAnakasuhService->AnakasuhFilters($query, $request);

        $perPage = (int) $request->input('limit', 25);
        $currentPage = (int) $request->input('page', 1);
        $results = $query->paginate($perPage, ['*'], 'page', $currentPage);

        if ($results->isEmpty()) {
            return response()->json([
                'status' => 'success',
                'message' => 'Data kosong',
                'data' => [],
            ], 200);
        }

        $formatted = $this->anakasuhService->formatData($results);

        return response()->json([
            'total_data' => $results->total(),
            'current_page' => $results->currentPage(),
            'per_page' => $results->perPage(),
            'total_pages' => $results->lastPage(),
            'data' => $formatted,
        ]);
    }

    public function getDetailAnakasuh(string $bioId)
    {
        $Anakasuh = Biodata::find($bioId);
        if (! $Anakasuh) {
            return response()->json([
                'status' => 'error',
                'message' => 'ID anak asuh tidak ditemukan',
                'data' => [],
            ], 404);
        }

        $data = $this->detailAnakasuhService->getDetailAnakasuh($bioId);

        return response()->json([
            'status' => true,
            'data' => $data,
        ], 200);
    }

    // public function index($bioId): JsonResponse
    // {
    //     try {
    //         $result = $this->anakasuhService->index($bioId);
    //         if (! $result['status']) {
    //             return response()->json([
    //                 'message' => $result['message'],
    //             ], 404);
    //         }

    //         return response()->json([
    //             'status' => true,
    //             'data' => $result['data'],
    //         ]);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'message' => 'Terjadi kesalahan saat memproses data',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }

    public function store(anakAsuhRequest $request)
    {
        try {
            $validated = $request->validated();
            $result = $this->anakasuhService->store($validated);

            return response()->json([
                'success' => true,
                'message' => $result['message'],
                'data' => [
                    'berhasil' => $result['data_baru'],
                    'gagal' => $result['data_gagal'],
                ],
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Terjadi kesalahan saat memproses permintaan.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function formStore(tambahAnakasuhRequest $request, $bioId): JsonResponse
    {
        try {
            $validated = $request->validated();
            $result = $this->anakasuhService->formStore($validated, $bioId);

            if (! $result['status']) {
                return response()->json([
                    'message' => $result['message'],
                ], 200);
            }

            return response()->json([
                'message' => 'Data berhasil ditambah',
                'data' => $result['data'],
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal tambah anakasuh: ' . $e->getMessage());

            return response()->json([
                'message' => 'Terjadi kesalahan saat memproses data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function show($id): JsonResponse
    {
        try {
            $result = $this->anakasuhService->show($id);

            if (! $result['status']) {
                return response()->json([
                    'message' => $result['message'] ?? 'Data tidak ditemukan.',
                ], 200);
            }

            return response()->json([
                'message' => 'Detail data berhasil ditampilkan',
                'data' => $result['data'],
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal ambil detail anakasuh: ' . $e->getMessage());

            return response()->json([
                'message' => 'Terjadi kesalahan saat menampilkan data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function update(tambahAnakasuhRequest $request, $id)
    {
        try {
            $result = $this->anakasuhService->update($request->validated(), $id);
            if (! $result['status']) {
                return response()->json([
                    'message' => $result['message'] ??
                        'Data tidak ditemukan.',
                ], 200);
            }

            return response()->json([
                'message' => 'anakasuh berhasil diperbarui',
                'data' => $result['data'],
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal update anakasuh: ' . $e->getMessage());

            return response()->json([
                'message' => 'Terjadi kesalahan saat memproses data.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function keluarAnakasuh(KeluarAnakasuhRequest $request, $id): JsonResponse
    {
        try {
            $validated = $request->validated();
            $result = $this->anakasuhService->keluarAnakasuh($validated, $id);

            if (! $result['status']) {
                return response()->json([
                    'message' => $result['message'],
                ], 200);
            }

            return response()->json([
                'message' => 'Data berhasil diperbarui',
                'data' => $result['data'],
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal keluar anakasuh: ' . $e->getMessage());

            return response()->json([
                'message' => 'Terjadi kesalahan saat memproses data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function pindahAnakasuh(PindahAnakasuhRequest $request, $id): JsonResponse
    {
        try {
            $validated = $request->validated();
            $result = $this->anakasuhService->pindahAnakasuh($validated, $id);

            if (! $result['status']) {
                return response()->json([
                    'message' => $result['message'],
                ], 200);
            }

            return response()->json([
                'message' => 'kewaliasuhan baru berhasil dibuat',
                'data' => $result['data'],
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal pindah anak asuh: ' . $e->getMessage());

            return response()->json([
                'message' => 'Terjadi kesalahan saat memproses data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function destroy($id)
    {
        DB::transaction(function () use ($id) {
            $anakasuh = Anak_Asuh::findOrFail($id);
            if (! $anakasuh) {
                return response()->json([
                    'success' => false,
                    'message' => 'anak asuh tidak ditemukan',
                ], 404);
            }
            $originalAttributes = $anakasuh->getAttributes();
            $relations = Kewaliasuhan::where('id_wali_asuh', $id)->get();
            // 1. Nonaktifkan semua relasi
            Kewaliasuhan::where('id_wali_asuh', $id)
                ->update([
                    'tanggal_berakhir' => now(),
                    'status' => false,
                    'deleted_at' => now(),
                    'deleted_by' => Auth::id(),
                ]);

            // 2. Nonaktifkan wali asuh
            Anak_Asuh::where('id', $id)
                ->update([
                    'status' => false,
                    'deleted_at' => now(),
                    'deleted_by' => Auth::id(),
                ]);

            activity('anak_asuh_delete')
                ->performedOn($anakasuh)
                ->withProperties([
                    'old_attributes' => $originalAttributes,
                    'deleted_by' => Auth::id(),
                    'ip' => request()->ip(),
                    'user_agent' => request()->userAgent(),
                    'affected_relations' => $relations->pluck('id'), // ID relasi yang dinonaktifkan
                ])
                ->event('nonaktif_wali_asuh')
                ->log('Wali asuh dinonaktifkan beserta semua relasinya');

            // Log untuk setiap relasi yang dinonaktifkan
            foreach ($relations as $relation) {
                activity('kewaliasuhan_delete')
                    ->performedOn($relation)
                    ->withProperties([
                        'id_wali_asuh' => $relation->id_wali_asuh,
                        'id_anak_asuh' => $relation->id_anak_asuh,
                        'deleted_by' => Auth::id(),
                    ])
                    ->event('nonaktif_relasi_wali_asuh')
                    ->log('Relasi kewaliasuhan dinonaktifkan karena wali asuh dinonaktifkan');
            }
        });

        return response()->json(['message' => 'Anak asuh dihapus']);
    }

    public function exportExcel(Request $request)
    {
        $defaultExportFields = [
            'nama',
            'jenis_kelamin',
            'nis',
            'angkatan_santri',
            'angkatan_pelajar',
            'grup',
            'wali_asuh',
            'created_at',
            'updated_at',
        ];

        $columnOrder = [
            'no_kk',           // di depan
            'nik',
            'niup',
            'nama',
            'tempat_tanggal_lahir',
            'jenis_kelamin',
            'anak_ke',
            'jumlah_saudara',
            'alamat',
            'nis',
            'domisili_santri',
            'angkatan_santri',
            'status',
            'no_induk',
            'pendidikan',
            'angkatan_pelajar',
            'ibu_kandung',
            'grup',
            'wali_asuh',
            'created_at',
            'updated_at',
        ];

        // Ambil kolom optional tambahan dari checkbox user (misal ['no_kk','nik',...])
        $optionalFields = $request->input('fields', []);

        // Gabung kolom default export + kolom optional (hindari duplikat)
        $fields = array_unique(array_merge($defaultExportFields, $optionalFields));
        $fields = array_values(array_intersect($columnOrder, $fields));

        // Gunakan query khusus untuk export (boleh mirip dengan list)
        $query = $this->anakasuhService->getExportAnakasuhQuery($fields, $request);
        $query = $this->filterAnakasuhService->AnakasuhFilters($query, $request);

        $query = $query->latest('b.created_at');

        // Jika user centang "all", ambil semua, else gunakan limit/pagination
        $results = $request->input('all') === 'true'
            ? $query->get()
            : $query->limit((int) $request->input('limit', 100))->get();

        // Format data sesuai urutan dan field export
        $addNumber = true; // Supaya kolom No selalu muncul
        $formatted = $this->anakasuhService->formatDataExportAnakasuh($results, $fields, $addNumber);
        $headings = $this->anakasuhService->getFieldExportAnakasuhHeadings($fields, $addNumber);

        $now = now()->format('Y-m-d_H-i-s');
        $filename = "data_anakasuh_{$now}.xlsx";

        return Excel::download(new BaseExport($formatted, $headings), $filename);
    }
    // public function berhentiAnakasuh(Request $request)
    // {
    //     $query = DB::table('anak_asuh as aa')
    //         ->join('santri AS s', 'aa.id_santri', '=', 's.id')
    //         ->join('biodata AS b', 's.biodata_id', '=', 'b.id')
    //         ->leftJoin(
    //             'domisili_santri AS ds',
    //             fn($j) =>
    //             $j->on('s.id', '=', 'ds.santri_id')
    //                 ->where('ds.status', 'aktif')
    //         )
    //         ->leftJoin('wilayah AS w', 'ds.wilayah_id', '=', 'w.id')
    //         ->select([
    //             'aa.id',
    //             'b.nama',
    //             's.nis',
    //             'w.nama_wilayah'
    //         ])
    //         ->where('aa.status', true)
    //         ->when($request->wali_asuh_id, function ($q) use ($request) {
    //             $q->where('aa.wali_asuh_id', $request->wali_asuh_id);
    //         })
    //         ->when($request->wilayah_id, function ($q) use ($request) {
    //             $q->where('ds.wilayah_id', $request->wilayah_id);
    //         })
    //         ->orderBy('b.nama')
    //         ->get();

    //     return response()->json([
    //         'status' => true,
    //         'data' => $query
    //     ]);
    // }
    // public function stop(BerhentiAnakAsuhRequest $request)
    // {
    //     try {
    //         // Validasi request
    //         $validated = $request->validated();

    //         // Panggil service untuk memproses penghentian anak asuh
    //         $result = $this->anakasuhService->stopAnakAsuh($validated);

    //         return response()->json([
    //             'success' => true,
    //             'message' => $result['message'],
    //             'data' => [
    //                 'berhasil' => $result['data_baru'],
    //                 'gagal' => $result['data_gagal'],
    //             ],
    //         ], 200);
    //     } catch (\Exception $e) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Terjadi kesalahan saat memproses permintaan.',
    //             'error' => $e->getMessage(),
    //         ], 500);
    //     }
    // }
}
